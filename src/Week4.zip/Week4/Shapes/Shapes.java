package Week4.Shapes;

public class Shapes {
    public interface Shape {
        public double area();
        public double perimeter();
    }
}
