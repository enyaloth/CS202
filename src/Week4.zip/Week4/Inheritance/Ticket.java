package Week4.Inheritance;

public interface Ticket {
    public int number = 0;

    public int Ticket(int number);
    public double getPrice();
    public String toString();
}
