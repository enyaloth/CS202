package Week4.Inheritance;

public class Lamb extends Ham {
    public void b() {
        System.out.println("Lamb b");
    }
}
