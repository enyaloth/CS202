package Week4.Inheritance;

public class Bar extends Foo {
    public void method2() {
        System.out.println("Bar 2");
    }
}
