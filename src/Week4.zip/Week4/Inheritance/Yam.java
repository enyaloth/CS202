package Week4.Inheritance;

public class Yam extends Lamb {
    public void a() {
        System.out.println("Yam a");
        super.a();
    }
    public String toString() {
        return "Yam";
    }
}
