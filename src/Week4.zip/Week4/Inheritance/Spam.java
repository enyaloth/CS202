package Week4.Inheritance;

public class Spam extends Yam {
    public void b() {
        System.out.println("Spam b");
    }
}
