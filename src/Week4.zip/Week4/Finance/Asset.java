package Week4.Finance;

public interface Asset {
    // Defining abstract method stubs
    public double getMarketValue();
    public double getProfit();
}
